### Hi Mastah BiiDev In Here <img src="https://raw.githubusercontent.com/MartinHeinz/MartinHeinz/master/wave.gif" width="30px">

<!--
**BiiDev/BiiDev** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->



## &#x1f4c8; GitHub Stats


<p align="center"> <img src="https://komarev.com/ghpvc/?username=scripter-ryu&label=Profile%20views&color=0e75b6&style=flat" alt="scripter-ryu" /> </p>


<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=scripter-ryu&show_icons=true&locale=en" alt="scripter-ryu" /></p>

## AwokAwok XD.

<img src="https://github.com/scripter-ryu/scripter-ryu/blob/main/FB_IMG_16260927396250433.jpg" width="640" title="AwokAwok XD." alt="Menu">
</p>

## MY SOCIAL MEDIA
[![Github](https://img.shields.io/badge/Github-Ikuti-green?style=for-the-badge&logo=github)](https://github.com/scripter-ryu/)
[![Youtube](https://img.shields.io/badge/Youtube-Subscribe-green?style=for-the-badge&logo=Youtube)](https://www.youtube.com/channel/UCpQbmees2Ja-LLFoOJ_K_eA)
[![Instagram](https://img.shields.io/badge/Instagram-Ikuti-green?style=for-the-badge&logo=Instagram)](https://www.instagram.com/ngemry7)
[![Whatsapp](https://img.shields.io/badge/Whatsapp-Chat-green?style=for-the-badge&logo=WhatsApp)](https://wa.me/+6281567607136?text=Assalamualaikum%20Bang)

## Beliin Gua Kopi Kek
[![Saweria](https://img.shields.io/badge/Donasi-green?style=for-the-badge&logo=Saweria)](https://saweria.co/orbxd)

  
[![ReadmeCard](https://github-readme-stats.vercel.app/api/pin/?username=scripter-ryu&repo=clanara&theme=chartreuse-dark)](https://github.com/scripter-ryu/clanara)

[![ReadmeCard](https://github-readme-stats.vercel.app/api/pin/?username=scripter-ryu&repo=BMBF&theme=chartreuse-dark)](https://github.com/scripter-ryu/BMBF)


<!-- Resources -->
<!-- Icons: https://simpleicons.org/ -->
<!-- GitHub Stats: https://github.com/scripter-ryu/github-readme-stats -->
<!-- Emojis: https://emojipedia.org/emoji/ -->
<!-- HTML Emojis: https://www.fileformat.info/index.htm -->
<!-- Shields: https://shields.io/ -->
<!-- Awesome GitHub Profile README: https://github.com/abhisheknaiidu/awesome-github-profile-readme -->
