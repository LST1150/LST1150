# ✭ BMBF PREMIUM

## ⇨  Login Methode
[✯] Login Token  

[✯] Login Cookie

[✯] Token/Cookie Tahan CheckPoint

## ⇨  Crack
[✯] Crack Default/Manual

[✯] Crack From Friend, Public, Followers, Likers

[✯] Crack By Email, Phone Number

[✯] Crack 5 Method + TTL

[✯] Crack Default 9 Password  

[✯] Crack BerPass Manual 

## ⇨  Install Script Termux

$ pkg update && upgrade  

$ pkg install python  

$ pkg install git  

$ pip install bs4  

$ pip install requests  

$ pip install mechanize  

$ pip install futures

$ pkg install git 

$ rm -rf BMBF

$ git clone https://www.github.com/dekura-x/BMBF

$ cd BMBF

$ python prem.py  

## ✭ Warning ✭ ##
```
Matikan Data Dan Mode Pesawat Sebelum Crack!

Jika Pake Wifi Tidak Ada Hasil Beralih Ke Data! 
```

## ✭ ScreenShot
 <img src="https://github.com/scripter-ryu/BMBF/blob/main/ScreenTod/20210715_085014.jpg" width="640" title="ScreenShot" alt="Menu">
</p>

## ✭ Report Bug
[![Instagram](https://img.shields.io/badge/Instagram-Report-green?style=for-the-badge&logo=Instagram)](https://www.instagram.com/ngemry7)

## ✭ Script Krek Terbaru
[![ReadmeCard](https://github-readme-stats.vercel.app/api/pin/?username=Dekura-X&repo=clanara&theme=chartreuse-dark)](https://github.com/Dekura-X/clanara)


